from django.apps import AppConfig


class CalculadoraConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'calculadora'
