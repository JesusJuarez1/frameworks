from django.contrib import admin
from .models import Horario

admin.site.register(Horario)