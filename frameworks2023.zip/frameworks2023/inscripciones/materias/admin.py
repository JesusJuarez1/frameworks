from django.contrib import admin
from .models import Materia, MateriasPrecedentes

admin.site.register(Materia)
admin.site.register(MateriasPrecedentes)