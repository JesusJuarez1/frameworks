from django.contrib import admin
from .models import Docente, Estado, Municipio

admin.site.register(Docente)
admin.site.register(Estado)
admin.site.register(Municipio)
