from django.contrib import admin
from .models import Salon

admin.site.register(Salon)