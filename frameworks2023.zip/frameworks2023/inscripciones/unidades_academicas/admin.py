from django.contrib import admin
from unidades_academicas.models import UnidadAcademica

admin.site.register(UnidadAcademica)