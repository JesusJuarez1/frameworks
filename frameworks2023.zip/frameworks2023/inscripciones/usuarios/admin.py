from django.contrib import admin
from .models import Docente, Alumno


admin.site.register(Docente)
admin.site.register(Alumno)
