from django.contrib import admin
from .models import Alumno

admin.site.register(Alumno)