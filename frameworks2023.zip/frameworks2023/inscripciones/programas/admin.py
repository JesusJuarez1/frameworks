from django.contrib import admin
from programas.models import ProgramaAcademico

admin.site.register(ProgramaAcademico)